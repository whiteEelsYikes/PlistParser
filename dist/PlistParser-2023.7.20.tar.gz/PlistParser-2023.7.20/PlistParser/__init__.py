#!/usr/bin/python3
# -*- coding: utf-8 -*-

from .Info import (

    __version__,
    __license__,
    __license_head__,
    __license_body__,
    open_project_link,

)
