#!/usr/bin/python3
# -*- coding: utf-8 -*-

class AttributeMappingDict:
    pass

class NameMappingDict:
    pass


